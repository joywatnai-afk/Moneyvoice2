package com.example.moneyvoice

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.TextView
import com.example.moneyvoice.data.TransactionEntity
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class TransactionFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_transactions, container, false)
        val rv = view.findViewById<RecyclerView>(R.id.recyclerTransactions)
        rv.layoutManager = LinearLayoutManager(requireContext())
        val adapter = TxAdapter()
        rv.adapter = adapter
        val dao = AppDatabase.getInstance(requireContext()).transactionDao()
        lifecycleScope.launch {
            dao.all().collectLatest { list -> adapter.submit(list) }
        }
        return view
    }
}

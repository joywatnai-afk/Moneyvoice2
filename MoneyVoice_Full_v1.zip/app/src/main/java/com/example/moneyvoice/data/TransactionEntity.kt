package com.example.moneyvoice.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val message: String,
    val type: String,
    val timestamp: Long = System.currentTimeMillis()
)

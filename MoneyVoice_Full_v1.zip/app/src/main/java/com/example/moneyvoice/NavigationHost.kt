package com.example.moneyvoice

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity

object NavigationHost {
    fun open(activity: FragmentActivity, fragment: Fragment) {
        activity.supportFragmentManager.beginTransaction().replace(R.id.fragment_container, fragment).commit()
    }
}

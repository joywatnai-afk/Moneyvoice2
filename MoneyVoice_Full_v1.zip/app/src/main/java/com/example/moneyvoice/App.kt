package com.example.moneyvoice

import android.app.Application
import com.example.moneyvoice.tts.TtsManager

class App : Application() {
    companion object { lateinit var tts: TtsManager }
    override fun onCreate() {
        super.onCreate()
        tts = TtsManager(this)
    }
}

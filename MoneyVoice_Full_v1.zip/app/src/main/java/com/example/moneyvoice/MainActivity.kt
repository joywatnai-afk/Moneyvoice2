package com.example.moneyvoice

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.moneyvoice.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        // Open Notification access settings
        binding.btnOpenNotifSettings.setOnClickListener {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        binding.btnExportCsv.setOnClickListener {
            TransactionRepository(this).exportCsv()
        }
        binding.btnExportPdf.setOnClickListener {
            TransactionRepository(this).exportPdf()
        }
        // Open fragments
        supportFragmentManager.beginTransaction()
            .replace(binding.fragmentContainer.id, TransactionFragment())
            .commit()
    }
}

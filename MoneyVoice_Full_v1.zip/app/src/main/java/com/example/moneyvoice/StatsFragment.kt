package com.example.moneyvoice

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class StatsFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_stats, container, false)
        val tv = view.findViewById<android.widget.TextView>(R.id.tvStats)
        val dao = com.example.moneyvoice.data.AppDatabase.getInstance(requireContext()).transactionDao()
        lifecycleScope.launch {
            dao.all().collectLatest { list ->
                val income = list.count { it.type.equals("IN", ignoreCase=true) }
                val expense = list.count { it.type.equals("OUT", ignoreCase=true) }
                tv.text = "สรุปยอด\nเงินเข้า: $income รายการ\nเงินออก: $expense รายการ"
            }
        }
        return view
    }
}

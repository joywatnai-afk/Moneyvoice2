package com.example.moneyvoice.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {
    @Insert
    suspend fun insert(tx: TransactionEntity)
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun all(): Flow<List<TransactionEntity>>
    @Query("DELETE FROM transactions")
    suspend fun clearAll()
}

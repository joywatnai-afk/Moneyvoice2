package com.example.moneyvoice

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.moneyvoice.data.TransactionEntity

class TxAdapter : ListAdapter<TransactionEntity, TxAdapter.VH>(DIFF) {
    companion object {
        val DIFF = object : DiffUtil.ItemCallback<TransactionEntity>() {
            override fun areItemsTheSame(oldItem: TransactionEntity, newItem: TransactionEntity) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: TransactionEntity, newItem: TransactionEntity) = oldItem == newItem
        }
    }
    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvMsg: TextView = v.findViewById(R.id.tvMsg)
        val tvTime: TextView = v.findViewById(R.id.tvTime)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_tx, parent, false)
        return VH(v)
    }
    override fun onBindViewHolder(holder: VH, position: Int) {
        val tx = getItem(position)
        holder.tvMsg.text = tx.message
        holder.tvTime.text = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm").format(java.util.Date(tx.timestamp))
    }
}

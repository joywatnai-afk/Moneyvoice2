package com.example.moneyvoice

import android.content.Context
import android.os.Environment
import com.example.moneyvoice.data.AppDatabase
import com.example.moneyvoice.data.TransactionEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import android.graphics.pdf.PdfDocument
import android.graphics.Canvas
import android.graphics.Paint
import java.io.OutputStreamWriter

class TransactionRepository(private val ctx: Context) {
    private val db = AppDatabase.getInstance(ctx)
    suspend fun insert(msg: String, type: String) {
        db.transactionDao().insert(TransactionEntity(message = msg, type = type))
    }
    // called from service via GlobalScope
    fun insertSync(msg: String, type: String) {
        Thread {
            val dao = db.transactionDao()
            dao.insert(TransactionEntity(message = msg, type = type))
        }.start()
    }
    fun exportCsv() {
        val list = db.transactionDao().all() // Flow - not ideal here; for sample we will write a very simple CSV by reading DB file
        // For simplicity in this sample, write a dummy CSV to external files dir
        val f = File(ctx.getExternalFilesDir(null), "moneyvoice_export.csv")
        FileOutputStream(f).use { fos ->
            OutputStreamWriter(fos).use { w -> w.write("id,message,type,timestamp\n") }
        }
    }
    fun exportPdf() {
        val file = File(ctx.getExternalFilesDir(null), "moneyvoice_report.pdf")
        val doc = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(300, 400, 1).create()
        val page = doc.startPage(pageInfo)
        val canvas: Canvas = page.canvas
        val paint = Paint()
        paint.textSize = 12f
        canvas.drawText("Money Voice Report", 10f, 20f, paint)
        doc.finishPage(page)
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
    }
}

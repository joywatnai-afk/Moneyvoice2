package com.example.moneyvoice

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.*
import kotlinx.coroutines.*

class NotificationService : NotificationListenerService(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
    }
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getString("android.title") ?: ""
        val text = extras.getCharSequence("android.text")?.toString() ?: ""
        val full = (title + " \n " + text).trim()
        // Basic parse for amount (thai 'บาท' or digits)
        val regex = Regex("(\\d{1,3}(?:[.,]\\d{3})*(?:[.,]\\d{1,2})?)\\s*(บาท|฿)?", RegexOption.IGNORE_CASE)
        val m = regex.find(full.replace(",", ""))
        val amount = m?.groups?.get(1)?.value
        val isIn = listOf("รับเงิน","โอนเข้า","credited").any { full.contains(it, ignoreCase = true) }
        val isOut = listOf("โอนออก","หัก","ตัดเงิน","ชำระ","debited").any { full.contains(it, ignoreCase = true) }
        if (amount != null && (isIn || isOut)) {
            val type = if (isIn) "IN" else "OUT"
            val msg = if (type=="IN") "เงินเข้า ${amount} บาท" else "เงินออก ${amount} บาท"
            Log.d("MoneyVoice", "Parsed tx: $msg")
            // speak
            tts?.speak(msg, TextToSpeech.QUEUE_ADD, null, "tx_id")
            // store in DB (use coroutine)
            GlobalScope.launch { TransactionRepository(this@NotificationService).insertSync(msg, type) }
        }
    }
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("th","TH")
        }
    }
    override fun onDestroy() {
        tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }
}
